export class ImaginaryFriend{
    constructor(
        public name : string,
        public occupation : string
    ){}
}