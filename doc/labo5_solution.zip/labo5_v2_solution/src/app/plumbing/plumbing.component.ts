import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plumbing',
  templateUrl: './plumbing.component.html',
  styleUrls: ['./plumbing.component.css']
})
export class PlumbingComponent implements OnInit {

  maDate : string = "2021-11-15";

  constructor() { }

  ngOnInit() {
  }

}
